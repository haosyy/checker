$ErrorActionPreference = "Stop"

$configPath = Join-Path $PSScriptRoot "config.json"
$resultPath = Join-Path $PSScriptRoot "result.json"

if (-not (Test-Path -LiteralPath $configPath -PathType Leaf)) {
    throw "Configuration file was not found: $configPath"
}

$config = Get-Content -LiteralPath $configPath -Raw | ConvertFrom-Json

foreach ($property in "gameProcessNames", "blockedProcessNames") {
    if ($null -eq $config.$property) {
        throw "Required configuration property is missing: $property"
    }
}

$found = @()
$scanErrors = @()

function Show-CheckProgress {
    param([int] $Step, [int] $Total, [string] $Activity)

    $percent = [Math]::Floor(($Step / $Total) * 100)
    Write-Progress -Activity "Anti-cheat check" -Status $Activity -PercentComplete $percent
    Write-Host "[$percent%] $Activity"
}

function Add-Finding {
    param(
        [Parameter(Mandatory)] [string] $Type,
        [Parameter(Mandatory)] [string] $Name,
        [Parameter(Mandatory)] [string] $Description,
        [string] $Location
    )

    $item = [ordered]@{
        type = $Type
        name = $Name
        description = $Description
    }

    if ($Location) {
        $item.location = $Location
    }

    $script:found += $item
}

function Expand-ConfiguredPath {
    param([Parameter(Mandatory)] [string] $Path)

    return [Environment]::ExpandEnvironmentVariables($Path)
}

function Get-ConfiguredValue {
    param([string] $PropertyName)

    if ($null -eq $config.$PropertyName) {
        return @()
    }

    return @($config.$PropertyName)
}

Show-CheckProgress -Step 1 -Total 8 -Activity "Checking configured process names"
foreach ($name in $config.blockedProcessNames) {
    if ([string]::IsNullOrWhiteSpace($name)) {
        continue
    }

    $processes = @(Get-Process -Name $name -ErrorAction SilentlyContinue)

    if ($processes.Count -gt 0) {
        Add-Finding -Type "process" -Name $name `
            -Description "Found a process listed in the configured rules."
    }
}

$gameProcesses = @(
    foreach ($name in $config.gameProcessNames) {
        if (-not [string]::IsNullOrWhiteSpace($name)) {
            Get-Process -Name $name -ErrorAction SilentlyContinue
        }
    }
)

Show-CheckProgress -Step 2 -Total 8 -Activity "Checking configured directories"
# Only the explicitly configured locations are checked. No disks are scanned.
foreach ($pathTemplate in Get-ConfiguredValue "suspiciousDirectories") {
    $path = Expand-ConfiguredPath $pathTemplate
    if (Test-Path -LiteralPath $path -PathType Container) {
        Add-Finding -Type "directory" -Name ([IO.Path]::GetFileName($path)) `
            -Description "Found a directory listed in the configured rules." -Location $path
    }
}

$keywords = @(Get-ConfiguredValue "suspiciousKeywords" | Where-Object {
    -not [string]::IsNullOrWhiteSpace($_)
})

if ($keywords.Count -gt 0) {
    Show-CheckProgress -Step 3 -Total 8 -Activity "Checking active processes"
    foreach ($process in Get-Process -ErrorAction SilentlyContinue) {
        $match = $keywords | Where-Object {
            $process.ProcessName.IndexOf($_, [StringComparison]::OrdinalIgnoreCase) -ge 0
        } | Select-Object -First 1

        if ($match) {
            Add-Finding -Type "process_keyword" -Name $process.ProcessName `
                -Description "Process name matches configured keyword '$match'." `
                -Location "PID $($process.Id)"
        }

        try {
            $processPath = $process.MainModule.FileName
            $match = $keywords | Where-Object {
                $processPath.IndexOf($_, [StringComparison]::OrdinalIgnoreCase) -ge 0
            } | Select-Object -First 1
            if ($match) {
                Add-Finding -Type "process_path" -Name $process.ProcessName `
                    -Description "Process executable path matches configured keyword '$match'." `
                    -Location $processPath
            }
        } catch {
            # Many protected processes do not expose an executable path.
        }
    }

    Show-CheckProgress -Step 4 -Total 8 -Activity "Checking startup entries"
    $runKeys = @(
        "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run",
        "HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce",
        "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run"
    )

    foreach ($runKey in $runKeys) {
        try {
            $values = Get-ItemProperty -Path $runKey -ErrorAction Stop
            foreach ($property in $values.PSObject.Properties | Where-Object { $_.Name -notmatch "^PS" }) {
                $text = "$($property.Name) $($property.Value)"
                $match = $keywords | Where-Object { $text.IndexOf($_, [StringComparison]::OrdinalIgnoreCase) -ge 0 } | Select-Object -First 1
                if ($match) {
                    Add-Finding -Type "startup_entry" -Name $property.Name `
                        -Description "Startup entry matches configured keyword '$match'." `
                        -Location $runKey
                }
            }
        } catch {
            # The key may not exist or may not be readable in this Windows edition.
        }
    }

    Show-CheckProgress -Step 5 -Total 8 -Activity "Checking scheduled tasks"
    try {
        foreach ($task in Get-ScheduledTask -ErrorAction Stop) {
            $taskText = "$($task.TaskPath)$($task.TaskName)"
            $match = $keywords | Where-Object { $taskText.IndexOf($_, [StringComparison]::OrdinalIgnoreCase) -ge 0 } | Select-Object -First 1

            if (-not $match) {
                foreach ($action in $task.Actions) {
                    $actionText = "$($action.Execute) $($action.Arguments)"
                    $match = $keywords | Where-Object { $actionText.IndexOf($_, [StringComparison]::OrdinalIgnoreCase) -ge 0 } | Select-Object -First 1
                    if ($match) { break }
                }
            }

            if ($match) {
                Add-Finding -Type "scheduled_task" -Name $task.TaskName `
                    -Description "Scheduled task matches configured keyword '$match'." `
                    -Location $task.TaskPath
            }
        }
    } catch {
        # Scheduled Tasks cmdlets may be unavailable or access-restricted.
    }
}

Show-CheckProgress -Step 6 -Total 8 -Activity "Checking HOSTS entries"
$hostsPath = Join-Path $env:WINDIR "System32\drivers\etc\hosts"
$hostDomains = @(Get-ConfiguredValue "hostBlockedDomains" | Where-Object {
    -not [string]::IsNullOrWhiteSpace($_)
})

if ($hostDomains.Count -gt 0 -and (Test-Path -LiteralPath $hostsPath -PathType Leaf)) {
    foreach ($line in Get-Content -LiteralPath $hostsPath -ErrorAction SilentlyContinue) {
        $content = ($line -replace "#.*$", "").Trim()
        if (-not $content) { continue }

        $match = $hostDomains | Where-Object { $content.IndexOf($_, [StringComparison]::OrdinalIgnoreCase) -ge 0 } | Select-Object -First 1
        if ($match) {
            Add-Finding -Type "hosts_entry" -Name $match `
                -Description "HOSTS entry contains a configured game-related domain." -Location $hostsPath
        }
    }
}

Show-CheckProgress -Step 7 -Total 8 -Activity "Checking launch history and configured file locations"
if ($keywords.Count -gt 0) {
    $historyLocations = @(
        (Join-Path $env:WINDIR "Prefetch"),
        (Join-Path $env:APPDATA "Microsoft\Windows\Recent")
    )

    foreach ($historyPath in $historyLocations) {
        if (-not (Test-Path -LiteralPath $historyPath -PathType Container)) { continue }
        try {
            foreach ($file in Get-ChildItem -LiteralPath $historyPath -File -ErrorAction Stop) {
                $match = $keywords | Where-Object {
                    $file.Name.IndexOf($_, [StringComparison]::OrdinalIgnoreCase) -ge 0
                } | Select-Object -First 1
                if ($match) {
                    Add-Finding -Type "launch_history" -Name $file.Name `
                        -Description "Launch-history filename matches configured keyword '$match'." `
                        -Location $file.FullName
                }
            }
        } catch {
            $scanErrors += "Could not read launch-history location: $historyPath"
        }
    }

    $extensions = @(Get-ConfiguredValue "scanFileExtensions" | ForEach-Object { $_.ToLowerInvariant() })
    foreach ($rootTemplate in Get-ConfiguredValue "scanRoots") {
        $root = Expand-ConfiguredPath $rootTemplate
        if (-not (Test-Path -LiteralPath $root -PathType Container)) { continue }
        try {
            foreach ($file in Get-ChildItem -LiteralPath $root -Recurse -File -Force -ErrorAction SilentlyContinue) {
                if ($extensions.Count -gt 0 -and $extensions -notcontains $file.Extension.ToLowerInvariant()) { continue }
                $match = $keywords | Where-Object {
                    $file.Name.IndexOf($_, [StringComparison]::OrdinalIgnoreCase) -ge 0
                } | Select-Object -First 1
                if ($match) {
                    Add-Finding -Type "file_name" -Name $file.Name `
                        -Description "Filename matches configured keyword '$match'." `
                        -Location $file.FullName
                }
            }
        } catch {
            $scanErrors += "Could not fully scan location: $root"
        }
    }
}

Show-CheckProgress -Step 8 -Total 8 -Activity "Checking configured game files"
foreach ($fileRule in Get-ConfiguredValue "expectedGameFiles") {
    if ([string]::IsNullOrWhiteSpace($fileRule.relativePath)) { continue }
    $gameFilePath = Join-Path $config.gameDirectory $fileRule.relativePath
    if (-not (Test-Path -LiteralPath $gameFilePath -PathType Leaf)) {
        Add-Finding -Type "game_file_missing" -Name $fileRule.relativePath `
            -Description "Configured game file was not found." -Location $gameFilePath
        continue
    }
    if ($null -ne $fileRule.sha256 -and -not [string]::IsNullOrWhiteSpace($fileRule.sha256)) {
        $actualHash = (Get-FileHash -LiteralPath $gameFilePath -Algorithm SHA256).Hash
        if ($actualHash -ne $fileRule.sha256.ToUpperInvariant()) {
            Add-Finding -Type "game_file_hash" -Name $fileRule.relativePath `
                -Description "Game file SHA-256 does not match the configured value." -Location $gameFilePath
        }
    }
}

$result = [ordered]@{
    computer = $env:COMPUTERNAME
    user = $env:USERNAME
    time = (Get-Date).ToUniversalTime().ToString("o")
    game_running = ($gameProcesses.Count -gt 0)
    status = if ($found.Count -eq 0) { "clean" } else { "suspicious" }
    found = $found
    scan_errors = $scanErrors
    checks = @(
        "blocked_processes",
        "game_processes",
        "configured_directories",
        "startup_entries",
        "scheduled_tasks",
        "hosts_entries",
        "launch_history",
        "configured_file_locations",
        "game_file_integrity"
    )
}

$result | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $resultPath -Encoding UTF8

$reportApiUrl = "$($config.reportApiUrl)".Trim()
if ($reportApiUrl) {
    try {
        $headers = @{}
        if ($env:REPORT_API_TOKEN) { $headers.Authorization = "Bearer $($env:REPORT_API_TOKEN)" }
        Invoke-RestMethod -Uri $reportApiUrl -Method Post -ContentType "application/json" `
            -Headers $headers -Body ($result | ConvertTo-Json -Depth 6) | Out-Null
        Write-Host "Report sent to the configured API."
    } catch {
        Write-Warning "Report was saved locally but could not be sent to the configured API."
    }
}

Write-Progress -Activity "Anti-cheat check" -Completed
Write-Host "Check complete."
Write-Host "Status: $($result.status)"
Write-Host "Found: $($found.Count)"
Write-Host "Result: $resultPath"
