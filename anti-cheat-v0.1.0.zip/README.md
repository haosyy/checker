# Anti-cheat prototype

This is a deliberately narrow first-stage prototype. It writes a local
`result.json` report after these read-only checks configured in `config.json`:

- blocked process names and game process names;
- explicitly listed application-data directories;
- Windows startup entries and scheduled tasks matching configured keywords;
- game-related entries in the Windows `HOSTS` file.

It does **not** scan memory, install or load drivers, enumerate disks, search
file contents, delete files, collect browser data, open websites, or make
network requests.

## Configure

Edit `config.json`:

- `gameProcessNames` lists process names used to decide whether the game is running.
- `blockedProcessNames` lists process names to flag for review.
- `gameDirectory` is retained for a later, explicit feature; this prototype does not access it.
- `suspiciousDirectories` contains exact paths to check. Environment variables
  such as `%APPDATA%` are expanded when the checker runs.
- `suspiciousKeywords` are matched against startup-entry names/commands and
  scheduled-task names/actions.
- `hostBlockedDomains` are matched against uncommented `HOSTS` entries.
- `scanRoots` are recursively checked by filename only; only files whose
  extension is in `scanFileExtensions` are considered. The scanner does not
  read their contents.
- `expectedGameFiles` can contain objects such as
  `{ "relativePath": "x64a.rpf", "sha256": "..." }` to verify a game file
  against a known SHA-256 hash. Leave it empty until you have an official hash
  for your exact game build.
- `reportApiUrl` is optional. If set, the JSON report is sent to that HTTPS
  API after it has been saved locally. Set `REPORT_API_TOKEN` in the execution
  environment if the API needs a bearer token. The Discord webhook belongs on
  this API server, never in the client or repository.

Matches are only leads, not proof of misconduct: names and paths can be
changed, while legitimate software can match a keyword. Review each item in
the report before acting.

## Run

Double-click `run-check.bat` and approve the UAC prompt. It starts
`checker.ps1` in an elevated PowerShell session and waits for it to finish.

Alternatively, run from PowerShell:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\checker.ps1
```

The scanner creates `result.json` beside the script. The report includes the
computer name, user name, UTC timestamp, game-running state, status, matching
configured process names, and the checks performed.

## Reporting and Discord

No webhook or other secret is stored in this repository or in `config.json`.
For production reporting, send the generated report over HTTPS to an
application-controlled API. That API should authenticate and validate the
request, then send a Discord notification using its server-side webhook secret.
This avoids distributing the Discord credential to clients.

Before distributing a future executable, publish an SHA-256 checksum with the
release and verify it before launch. Code-signing the executable with
Authenticode is also recommended.
