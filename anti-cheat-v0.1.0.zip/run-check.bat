@echo off
set "SCRIPT=%~dp0checker.ps1"

powershell.exe -NoProfile -Command ^
"Start-Process powershell.exe -Verb RunAs -Wait -ArgumentList '-NoProfile -ExecutionPolicy Bypass -File ""%SCRIPT%""'"

exit /b %ERRORLEVEL%
